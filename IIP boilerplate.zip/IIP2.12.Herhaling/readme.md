# Introductie in Programmeren 2

## Herhalingsoefeningen
