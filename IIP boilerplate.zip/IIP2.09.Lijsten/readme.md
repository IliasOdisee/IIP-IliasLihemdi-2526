# Introductie in Programmeren 2

## Oefeningen 09.lijsten
