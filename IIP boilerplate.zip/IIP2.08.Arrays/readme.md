# Introductie in Programmeren 2

## Oefeningen 08.arrays
